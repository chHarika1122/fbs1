package com.capgemini.fms.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FeedbackService;
import com.capgemini.fms.service.Validator;
import com.cg.fms.Exception.exception;

public class Client {

	static	FeedbackService fbs=new FeedbackService();
	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void showMenu(){

		System.out.println("1.Add Feedback Details");
		System.out.println("2.Get Feedback Report");
		System.out.println("3.Exit");
		System.out.println("4.Enter your choice");

	}
	public static void main(String[] args) throws exception, IOException {
		Scanner sc=new Scanner(System.in);
		int choice;
		String name="";
		String subject;
		int rating=0;
		String input="";
		while(true) {

			showMenu();
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				try {
					//Teacher name
					System.out.println("Enter Teacher name:");
					while(true) {
						input=br.readLine();
						boolean ch1=Validator.validatedata(input, Validator.name);
						if(ch1==true)
						{
							name=input;
							break;


						}
						else
							System.out.println("Re Enter Teacher Name"); 

					}
					//rating 
					System.out.println("Enter rating");
					while(true)
					{
						input=br.readLine();
						boolean ch1=Validator.validatedata(input, Validator.rating);
						if(ch1==true)
						{
							try {
								rating= Integer.parseInt(input);
								break;
							}
							catch(NumberFormatException e)

							{
								System.out.println(" Re Enter rating"); 
							}
						}else {
							System.out.println("Re enter rating:");
						}
					}
					//subject
					System.out.println("Enter subject name:");
					while(true) {
						input=br.readLine();
						boolean ch1=Validator.validatedata(input, Validator.subject);
						if(ch1==true)
						{
							subject=input;
							break;


						}
						else
							System.out.println("Re Enter subject Name"); 

					}
					fbs.addFeedbackDetails(name,rating, subject);
					System.out.println("Feedback added successfully");

				}catch(exception e) {
					System.out.println("Error : "+e.getMessage());
				}
				break;

			case 2:

				System.out.println("Enter subject name:");
				while(true) {
					input=br.readLine();
					boolean ch1=Validator.validatedata(input, Validator.subject);
					if(ch1==true)
					{
						subject=input;
						break;


					}
					else
						System.out.println("Re Enter subject Name"); 

				}
				System.out.println("Feedback details are:");
				Map<String,Integer> result=fbs.getFeedbackReport(name,rating,subject);
				Set set1=result.entrySet();
				Iterator i1=set1.iterator();
				while(i1.hasNext()) {
					Map.Entry me1=(Map.Entry)i1.next();
					System.out.println(me1.getKey()+" "+me1.getValue());
				}
break;
			case 3:

				sc.close();
			
			}
		}
	}
}


