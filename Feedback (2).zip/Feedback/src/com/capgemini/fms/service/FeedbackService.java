package com.capgemini.fms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.dao.FeedbackDAO;
import com.capgemini.fms.dao.IFeedbackDAO;
import com.cg.fms.Exception.exception;

public class FeedbackService implements IFeedbackService {
	IFeedbackDAO ifd=new FeedbackDAO();
	
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) throws exception {
		// TODO Auto-generated method stub
		
		return ifd.addFeedbackDetails(name, rating, subject);
	}

	@Override
	public Map<String, Integer> getFeedbackReport(String name, int rating, String subject) {
		// TODO Auto-generated method stub
		return ifd.getFeedbackReport(name, rating, subject);
	}

	
	}
