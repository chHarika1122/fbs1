package com.capgemini.fms.service;

import java.util.Map;

import com.cg.fms.Exception.exception;

public interface IFeedbackService {
Map<String,Integer>addFeedbackDetails(String name, int rating, String subject) throws exception;
Map<String,Integer>getFeedbackReport(String name, int rating, String subject);
}
