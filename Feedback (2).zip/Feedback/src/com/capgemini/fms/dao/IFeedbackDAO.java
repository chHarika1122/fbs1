package com.capgemini.fms.dao;

import java.util.Map;

import com.cg.fms.Exception.exception;

public interface IFeedbackDAO {
Map<String,Integer>addFeedbackDetails(String name,int rating,String subject)throws exception;
Map<String,Integer>getFeedbackReport(String name, int rating, String subject);	

}
