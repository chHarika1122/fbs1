package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.capgemini.fms.bean.Feedback;
import com.cg.fms.Exception.exception;

public class FeedbackDAO implements IFeedbackDAO{
	Map<String,Integer>mathFeedbackMap=new HashMap<>();
	Map<String,Integer>englishFeedbackMap=new HashMap<>();
	Map<String,Integer>consolidatedMap=new HashMap();
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) throws exception {
		
		
			
		Map<String,Integer>result=new HashMap();

		if(subject.equalsIgnoreCase("math")) {
			mathFeedbackMap.put( name, rating);
			result=mathFeedbackMap;
		
		}
		
		else if(subject.equalsIgnoreCase("English")) {
			englishFeedbackMap.put( name, rating);
			result=englishFeedbackMap;
				
		}
		return result;
		



	}
	@Override
	public Map<String, Integer> getFeedbackReport(String name, int rating, String subject) {
		// TODO Auto-generated method stub
		
		
		consolidatedMap.putAll(mathFeedbackMap);
		
		
		consolidatedMap.putAll(englishFeedbackMap);

	
		return consolidatedMap;
		

	}

}
/*if(subject.equals(c)) {
//Feedback fb=new Feedback(name, rating);
englishFeedbackMap.put(name,rating);
Set set1=englishFeedbackMap.entrySet();
Iterator i1=set1.iterator();
while(i1.hasNext()) {
	Map.Entry me1=(Map.Entry)i1.next();
	System.out.println(me1.getKey()+" "+me1.getValue());
}
}*/

