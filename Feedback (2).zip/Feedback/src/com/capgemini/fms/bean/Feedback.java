package com.capgemini.fms.bean;

public class Feedback {
	private String teacherName;
	private int rating;
	private String subject;
public Feedback(String Name, int rating, String subject) {
	this.teacherName=Name;
	this.rating=rating;
	this.subject=subject;
}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject() {
		this.subject = subject;
	}
	
	

}
